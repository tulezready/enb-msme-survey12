-- ============================================================
-- ENB Division of Commerce & Industry — Economic & MSME Survey
-- Supabase schema
-- Run this whole file once in: Supabase Dashboard -> SQL Editor -> New query
-- ============================================================

-- Main survey table. Repeating sections from the paper form (tables,
-- checklists) are stored as JSONB arrays/objects so the whole survey
-- is one row per household/business.
create table if not exists public.msme_surveys (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),

  -- A) Location
  district text,
  llg text,
  village text,
  ward text,
  household_no text,
  date_collected date,
  contact_person text,
  mobile_number text,
  postal_address text,
  enumerator_name text,

  -- B) Employment & Education
  employed_count int,
  employed_members jsonb not null default '[]',   -- Table 1: [{name, qualification, institution, year_graduated, employer_location, gross_monthly_pay}]
  unemployed_members jsonb not null default '[]',  -- Table 2: [{name, qualification, institution, year_graduated, comments}]
  unemployed_comments text,

  -- Business status drives which of C/D/E show in the app
  -- 'formal' | 'informal' | 'none'
  business_status text,

  -- C) Business Background
  business_activities jsonb not null default '{"selected":[],"others":""}',
  business_name text,
  business_date_commenced date,
  business_owner text,
  other_business_location text,
  ipa_registered boolean,
  ipa_registrations jsonb not null default '[]', -- [{form, date_reg, reg_no, expiry}]
  licenses jsonb not null default '[]',           -- [{type, ticked, receipt_no, expiry}]
  licenses_comment text,
  trading_license_url text,                       -- uploaded PDF/photo of trading license
  has_business_loan boolean,
  business_loans jsonb not null default '[]',     -- [{bank, amount, date, on_schedule, comments}]
  no_loan_reasons text,

  -- D) Business Development Assistance
  trainings_attended jsonb not null default '[]', -- [{type, attended, facilitator}]
  training_workshop_attended boolean,
  trainings_required jsonb not null default '{"selected":[],"others":""}',
  assistance_required jsonb not null default '{"selected":[],"others":""}',
  assistance_comment text,

  -- E) Economic Output Development
  emp_casuals_no int,
  emp_casuals_years int,
  emp_permanent_no int,
  emp_permanent_years int,
  wages_casual_fortnightly numeric,
  wages_permanent_fortnightly numeric,
  turnover_bracket text,    -- 'a' | 'b' | 'c' | 'd'
  turnover_amount numeric,
  expenses_bracket text,    -- '1' | '2' | '3' | '4'
  expenses_amount numeric,
  initial_capital numeric,
  asset_value numeric,
  other_investments numeric,
  other_investments_specify text,

  -- F) Cash Crops (always shown)
  cash_crops jsonb not null default '[]',  -- [{crop, blocks, trees}]
  cash_crops_comment text,

  -- G) Informal Business Sector (always shown)
  informal_businesses jsonb not null default '[]', -- [{owner_name, activity_type, year_established, monthly_turnover}]
  informal_comment text
);

-- Keep updated_at current on edits
create or replace function public.set_updated_at()
returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

drop trigger if exists trg_msme_surveys_updated on public.msme_surveys;
create trigger trg_msme_surveys_updated
  before update on public.msme_surveys
  for each row execute function public.set_updated_at();

-- Helpful indexes for dashboard/search
create index if not exists idx_msme_surveys_district on public.msme_surveys (district);
create index if not exists idx_msme_surveys_business_status on public.msme_surveys (business_status);
create index if not exists idx_msme_surveys_created_at on public.msme_surveys (created_at desc);

-- ============================================================
-- Row Level Security
-- Same pattern as the JASCO app: open read/write for the team,
-- since the app itself is the access control (not public-facing).
-- ============================================================
alter table public.msme_surveys enable row level security;

drop policy if exists "Allow all access" on public.msme_surveys;
create policy "Allow all access"
  on public.msme_surveys
  for all
  using (true)
  with check (true);

-- ============================================================
-- Realtime (so the dashboard updates live across devices)
-- ============================================================
alter publication supabase_realtime add table public.msme_surveys;

-- ============================================================
-- Storage bucket for trading license uploads (PDF/photo)
-- ============================================================
insert into storage.buckets (id, name, public)
values ('trading-licenses', 'trading-licenses', true)
on conflict (id) do nothing;

drop policy if exists "Public read trading licenses" on storage.objects;
create policy "Public read trading licenses"
  on storage.objects for select
  using (bucket_id = 'trading-licenses');

drop policy if exists "Public upload trading licenses" on storage.objects;
create policy "Public upload trading licenses"
  on storage.objects for insert
  with check (bucket_id = 'trading-licenses');

drop policy if exists "Public update trading licenses" on storage.objects;
create policy "Public update trading licenses"
  on storage.objects for update
  using (bucket_id = 'trading-licenses');

drop policy if exists "Public delete trading licenses" on storage.objects;
create policy "Public delete trading licenses"
  on storage.objects for delete
  using (bucket_id = 'trading-licenses');
